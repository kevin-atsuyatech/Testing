import json
import serial
import time
import re
import logging
import subprocess
import os
from collections        import deque
from getmac             import get_mac_address
from logging.handlers   import RotatingFileHandler
from datetime           import datetime, timedelta, timezone
from gpiozero           import LED, DigitalInputDevice
from enum               import Enum, auto, IntEnum
import sqlite3
import traceback
from aone_modbus        import (parseConfigJSON, 
                                CONFIG_FILE, 
                                VARIABLE_FILE,
                                DB_PATH,
                                TABLE_NAME  )

#EC200U 4G Module
PWRKEY_PIN      = 26
STATUS_PIN      = 19
SERIAL_PORT     = "/dev/ttyAMA5"
BAUDRATE        = 115200
PWR_KEY         = LED(PWRKEY_PIN)
POWER_STATUS    = DigitalInputDevice(STATUS_PIN, pull_up= True)

#CM4
MAC             = get_mac_address(interface="wlan0").upper()
NUM_RECORDS     = 20                    # No of records to be published at once

#Time/clock config
SYNC_INTERVAL   = 7*24*3600 #once a week
SYNC_FILE       = "/var/log/adas/config/last_sync_time.txt"
IST             = timezone(timedelta(hours=5, minutes=30))

#MQTT config
BROKER_ADDRESS  = "iot.atsuyatech.com"
MQTT_USERNAME   = "Atsuya"
MQTT_PWD        = "Atsuya123"
NTP_SERVER      = "ntp.atsuyatech.com"
PUBLISH_TOPIC   = "Aone/Vone/testing/tcp"
SUB_TOPIC       = f"Aone/Vone/testing/commands/{MAC}"
RESPONSE_TOPIC  = "Aone/Vone/testing/status"

#Log Config
MAX_LOG_SIZE    = 10 * 1024 * 1024                              # 1 MB (adjust as needed)
BACKUP_COUNT    = 5                                             # Number of backup log files to keep
LOG_FORMAT      = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

class DEV_State(Enum):
    POWERED_OFF         = 0
    POWER_ON            = 1
    INTERNET_CONNECTED  = 2
    MQTT_CONNECTED      = 3

class ERR_Codes(Enum):
    ERR_DEVICE_PWR_OFF      = auto() 
    ERR_RESPONSE_TIMEOUT    = auto()
    ERR_ERROR               = auto()
    ERR_CME_ERROR           = auto()
    NO_ERR                  = auto()

class PWR_State(Enum):
    TURN_ON             = 0
    SHUTDOWN            = 1
    REBOOT              = 2

class Config_Commands(IntEnum):
    READ_FIRMWARE_VERSION   = 103
    WRITE_TIMEOUT_CONFIG    = 104
    PUSH_OTA_UPDATE         = 110
    REBOOT                  = 113
    CLEAR_MODBUS_CONFIG     = 114
    REMOVE_DEVICE_CONFIG    = 115
    DELETE_DATABASE         = 116
    WRITE_MODBUS_CMD        = 301
    READ_MQTT_CONF          = 303
    GET_IP_ADDRESS          = 305
    READ_NODE_CONF          = 306
    CHANGE_MODBUS_IP        = 311


ResponseQueue = deque()
GLOB_DEV_STATUS:DEV_State = DEV_State.POWERED_OFF



def setSystemTime(dt: datetime) -> bool:
    """
    Set system time using the 'date' command (requires sudo).
    """
    try:
        date_str = dt.strftime('%m%d%H%M%Y.%S')  # Format: MMDDhhmmYYYY.SS
        subprocess.run(['sudo', 'date', date_str], check=True)
        return True
    except Exception as exc:
        datalogger.error(f"Cannot set time: {exc}")
        datalogger.error(traceback.format_exc())
    return False

    #set time in RTC module
    # # Format: MMDDhhmmYYYY.ss
    # formatted_time = dt.strftime('%m%d%H%M%Y.%S')
    # try:
    #     # Set system time
    #     subprocess.run(['sudo', 'date', formatted_time], check=True)
    #     datalogger.info("System time set.")
    # except subprocess.CalledProcessError as e:
    #     datalogger.error(f"Failed to set system time: {e}")
    #     return False

    # try:
    #     # Sync system time to RTC
    #     subprocess.run(['sudo', 'hwclock', '-w'], check=True)
    #     datalogger.info("RTC updated.")
    # except subprocess.CalledProcessError as e:
    #     datalogger.error(f"Failed to update RTC: {e}")
    #     return False
    # return True


def parseQntpResponse(response) -> tuple[ERR_Codes, dict]:
    try:
        # Extract the quoted part: "2025/04/17,11:12:06+22"
        parts = response.split('"')[1]
        date_part, time_with_offset = parts.split(',')

        # Extract time and timezone offset
        time_part = time_with_offset[:-3]              # "11:12:06"
        tz_offset_quarters = int(time_with_offset[-3:])  # "+22" → 22 * 15 mins

        # Calculate UTC offset
        offset_minutes = tz_offset_quarters * 15
        offset = timedelta(minutes=offset_minutes)
        tzinfo = timezone(offset)

        # Parse the datetime assuming it's in UTC
        utc_dt = datetime.strptime(f"{date_part} {time_part}", "%Y/%m/%d %H:%M:%S")
        utc_dt = utc_dt.replace(tzinfo=timezone.utc)

        # Convert to local timezone
        local_dt:datetime = utc_dt.astimezone()

        # Epoch time is from UTC, so we can take it from utc_dt directly
        epoch_time = int(utc_dt.timestamp())

        return ( ERR_Codes.NO_ERR, {
            "utc_time": utc_dt.isoformat(),
            "local_time": local_dt.strftime("%Y-%m-%d %H:%M:%S"),
            "epoch": epoch_time,
            "datetime_obj" : local_dt
        } )

    except Exception as e:
        datalogger.error(traceback.format_exc())
        return ( ERR_Codes.ERR_ERROR, {"error": str(e)})


def sendATcommand(cmd:str, timeout:int = 1, expected_response:str = "OK") -> tuple[ERR_Codes, str]:
    if CheckDevPowerState() == DEV_State.POWERED_OFF:
        return (ERR_Codes.ERR_DEVICE_PWR_OFF, "")
    
    datalogger.debug(f"Sending cmd: {cmd}")
    response = []
    found:bool = False
    # Append carriage return + newline
    full_cmd:str = cmd + "\r\n"                                         
    start_time:float = time.time()
    ser.write(full_cmd.encode())
    
    while (time.time() - start_time) < timeout:
        # Read available bytes
        while ser.in_waiting > 0:
            data = ser.read(ser.in_waiting).decode(errors="ignore")
            response.append(data)
            combined = "".join(response)
            # Check for expected string if specified
            if "ERROR" in combined:
                datalogger.info(f"sent AT cmd: {cmd}")
                datalogger.warning(f"{combined.strip()}")
                return (ERR_Codes.ERR_ERROR, "")
            if "+CME ERROR:" in combined:
                datalogger.info(f"sent AT cmd: {cmd}")
                datalogger.warning(f"{combined.strip()}")
                return (ERR_Codes.ERR_CME_ERROR, "")
            if expected_response and expected_response in combined:
                found = True
                break 
        if found:
            break
        time.sleep(0.5)  # Prevent CPU hogging
    else:
        datalogger.warning("Timeout")
        return (ERR_Codes.ERR_RESPONSE_TIMEOUT, "")
    
    time.sleep(0.5)
    response.append(ser.read_all().decode(errors="ignore"))
    at_response = "".join(response).strip()
    datalogger.debug(f"cmd response: {at_response}")
    return (ERR_Codes.NO_ERR, at_response)


def CheckInternetConnected() -> bool:
    datalogger.debug("Checking Internet connection ....")
    response = sendATcommand("AT+QIACT?",  timeout=30, expected_response="+QIACT:")
    if response[0] != ERR_Codes.NO_ERR:
        datalogger.warning("Internet Disconnected")
        return False
    else:
        match = re.search(r'\+QIACT:\s*\d+,\d+,(\d+),"([\d.]+)"', response[1])
        if match:
            context_state = int(match.group(1))
            if context_state == 1:
                datalogger.debug(f"Internet connected, IP Address: {match.group(2)}")
                return True
        else:
            datalogger.error("Invalid or unexpected response")
        datalogger.warning("Internet Disconnected")
        return False


def checkMqttConnStatus() -> bool:
    if not CheckInternetConnected():
        return False
    datalogger.info("Checking MQTT status ....")
    response = sendATcommand("AT+QMTCONN?", timeout=20, expected_response="+QMTCONN:")
    if response[0] != ERR_Codes.NO_ERR:
        datalogger.warning("MQTT Disconnected")
        return False
    
    match = re.search(r"\+QMTCONN: \d,(\d)", response[1])
    if match:
        value = int(match.group(1))
        if value == 3:
            datalogger.debug("MQTT Connected")
            return True
    else:
        datalogger.error("No match found")
    datalogger.warning("Unable to connect to MQTT")
    return False


def CheckDevPowerState() -> DEV_State:
    if POWER_STATUS.value == 0:
      return DEV_State.POWERED_OFF
    return DEV_State.POWER_ON


def CheckDevConnState() -> DEV_State:
    if CheckInternetConnected() == False:
        return DEV_State.POWER_ON
    if checkMqttConnStatus() == False:
        return DEV_State.INTERNET_CONNECTED
    return DEV_State.MQTT_CONNECTED


def ChangePowerState(state:PWR_State) -> DEV_State:
    def power_on():
        if CheckDevPowerState() == DEV_State.POWERED_OFF:
                PWR_KEY.on()
                time.sleep(3)
                PWR_KEY.off()
                time.sleep(2)
                PWR_KEY.on()
                time.sleep(5)
    def power_off():
        if CheckDevPowerState() == DEV_State.POWER_ON:
                ser.write("AT+QPOWD\r\n".encode())
                time.sleep(5)
    match state:
        case PWR_State.REBOOT:
            power_off()
            time.sleep(1)
            power_on()
        case PWR_State.SHUTDOWN:
            power_off()
        case PWR_State.TURN_ON:
            power_on()
    return CheckDevPowerState()


def getOTApackage(update_link:str, timeout:int, filename:str) -> bool:
    if not CheckInternetConnected():
        return False
    sendATcommand("AT+QHTTPCFG=\"contenttype\", 2")
    sendATcommand(f"AT+QHTTPURL={len(update_link)},{timeout}", timeout=timeout, expected_response="CONNECT")
    sendATcommand(f"{update_link}", timeout=timeout)
    response = sendATcommand(f"AT+QHTTPGET={timeout}", timeout=timeout, expected_response="+QHTTPGET:")
    if response[0] != ERR_Codes.NO_ERR:
        return False
    match = re.search(r'\+QHTTPGET:\s*(\d+),(\d+),(\d+)', response[1])
    if not match:
        datalogger.error("no match found")
        return False
    result_code = int(match.group(1))
    http_status = int(match.group(2)) if match.group(2) else None
    data_length = int(match.group(3)) if match.group(3) else None
    if result_code != 0:
        datalogger.warning(f"Cannot connect to URL code {result_code}")
        return False
    if http_status != 200:
        datalogger.warning(f"Unable to fetch response. status:{http_status}")
        return False
    http_payload = bytearray()
    data_length += 11
    ser.write(f"AT+QHTTPREAD={timeout}\r\n".encode())
    start_time:float = time.time()
    last_log_time:float = start_time
    while (time.time() - start_time) < timeout:
        if len(http_payload) >= data_length:
            break
        
        # Read available bytes
        if ser.in_waiting > 0:
            data = ser.read(ser.in_waiting)
            start_time = time.time()
            http_payload.extend(data)
        
        # Log every 2 seconds
        if time.time() - last_log_time >= 2:
            percent = (len(http_payload) / data_length) * 100
            datalogger.info(f"Downloading... {len(http_payload)} / {data_length} bytes ({percent:.1f}%)")
            last_log_time = time.time()          
    else:
        datalogger.warning("HTTP response Timeout")
        return False
    http_payload = http_payload[11:data_length]
    try:
        with open(filename, "wb") as f:
            f.write(http_payload)
            return True
    except Exception as exc:
        datalogger.error(f"Error occured while saving OTA package {exc}")
    return False


def parseConfigCmds(msg:dict) -> None:
    #debugging
    # print("CMD type:", type(msg["cmd"]), "value:", msg["cmd"])
    # print("enum type:", type(Config_Commands.READ_FIRMWARE_VERSION), "value:", Config_Commands.READ_FIRMWARE_VERSION)
    cmd = msg.get("cmd")
    if cmd is None:
        datalogger.warning("Missing 'cmd' in received message")
        return

    response = {"cmd": cmd, "deviceId": MAC}
    match cmd:
        case Config_Commands.READ_FIRMWARE_VERSION:
            try:
                result = subprocess.run(
                    ["dpkg-query", "-W", "-f=${Version}", "aone-modbus-app"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    check=True,
                    text=True
                )
                response["firm_version"] = result.stdout.strip()
                ResponseQueue.append(response)
                datalogger.info(f"Read firmware version\nResponse: {response}")
            except subprocess.CalledProcessError as e:
                datalogger.error(f"Error: {e.stderr}")
        case Config_Commands.REBOOT:
            datalogger.warning("Rebooting device in 5 sec")
            time.sleep(5)
            subprocess.run(['sudo', 'reboot'])
        case Config_Commands.WRITE_TIMEOUT_CONFIG:
            try:
                with open(VARIABLE_FILE, "r+") as f:
                    env_vars = json.load(f)
                    env_vars["READ_INTERVAL"] = msg["timeout"]["measurement_interval"]
                    f.seek(0)              # Move to the beginning
                    json.dump(env_vars, f)
                    f.truncate()
                    datalogger.info(f"Timeout changed to {env_vars['READ_INTERVAL']}")
            except Exception as exc:
                datalogger.warning(f"{exc}")
                datalogger.error(traceback.format_exc())
        case Config_Commands.CHANGE_MODBUS_IP:
            try:
                with open(VARIABLE_FILE, "r+") as f:
                    env_vars = json.load(f)
                    env_vars["IP_ADDRESS"]  = msg["ip_addr"]
                    env_vars["PORT"]        = int(msg["port"])
                    f.seek(0)              # Move to the beginning
                    json.dump(env_vars, f)
                    f.truncate()
                    datalogger.info(f"IP changed to {env_vars['IP_ADDRESS']}\nPORT changed to {env_vars['PORT']}")
            except Exception as exc:
                datalogger.warning(f"{exc}")
                datalogger.error(traceback.format_exc())
        case Config_Commands.WRITE_MODBUS_CMD:
            if parseConfigJSON(msg["conf"]):
                datalogger.info("config parsed successfully")
                try:
                    with open(CONFIG_FILE, "w") as f:
                        json.dump(msg["conf"], f, indent=4)
                    response["Response"] = "Config Updated"
                except Exception as exc:
                    datalogger.error(f"cannot save {CONFIG_FILE} exception: {exc}")
                    response["Response"] = f"file error {exc}"
                    datalogger.error(traceback.format_exc())
            else:
                response["Response"] = f"Cannot parse config"
                datalogger.error("Cannot parse config")
            ResponseQueue.append(response)
        case Config_Commands.PUSH_OTA_UPDATE:
            try:
                update_link = msg["url"]
                http_timeout = msg.get("timeout", 80)
                package_path = "/tmp/aone_modbus_app_v" + msg.get("version", "Unknown") + ".deb"
                if getOTApackage(update_link=update_link, timeout=http_timeout, filename=package_path):
                    datalogger.info("File downloaded, trying to install")
                    ota_script_path = "install_ota.sh"

                    # Run shell script in background using nohup
                    subprocess.run(
                        [
                            "systemd-run",
                            "--unit=adas-ota",
                            "--property=Type=oneshot",
                            "--property=RemainAfterExit=no",
                            ota_script_path,
                            package_path
                        ],
                        check=True
                    )
                    response["status"] = "OTA success"
                else:
                    response["status"] = f"OTA Failed"
            except Exception as exc:
                datalogger.warning(f"{exc}")
                datalogger.error(traceback.format_exc())
                response["status"] = f"OTA Failed"
            ResponseQueue.append(response)
        case _:
            datalogger.warning(f"Unknown cmd: {cmd}")


def parseReceivedMsgs(raw:str) -> None:
    """
    Parse +QMTRECV messages using byte length, safely extracting multiline payloads.
    """
    raw_bytes = raw.encode('utf-8')  # ensure consistent encoding

    # This regex finds the start of each message using bytes
    pattern = re.compile(rb'\+QMTRECV: (\d+),(\d+),"([^"]+)",(\d+),"')

    pos = 0
    while True:
        match = pattern.search(raw_bytes, pos)
        if not match:
            break

        # client_idx = int(match.group(1))
        # msgid = int(match.group(2))
        # topic = match.group(3).decode()
        length = int(match.group(4))

        payload_start = match.end()
        payload_end = payload_start + length
        payload_bytes = raw_bytes[payload_start:payload_end]
        payload = payload_bytes.decode(errors='replace')  # or use 'strict'
        payload = json.loads(payload)
        datalogger.info(f"Received message:\n{payload}")
        parseConfigCmds(payload)
        pos = payload_end + 1  # move to next message
    return


def checkBufferedMsgs() -> int:
    response = sendATcommand("AT+QMTRECV?", timeout=20, expected_response="+QMTRECV:")
    if response[0] != ERR_Codes.NO_ERR:
        return False
    
    for line in response[1].strip().splitlines():
        if line.startswith("+QMTRECV:"):
            parts = line.split(':')[1].strip().split(',')
            buffer_flags = map(int, parts[1:])  # skip client_idx
            return sum(buffer_flags)
    return 0  # Default 


def GetSignalStrength() -> int:
    """
    Parses +QCSQ response for both LTE and GSM modes.

    Returns:
        rssi as int
    """
    response = sendATcommand("AT+QCSQ", timeout = 3)
    if response[0] != ERR_Codes.NO_ERR:
        return -127
    # LTE pattern
    lte_match = re.search(r'\+QCSQ:\s*"LTE",(\d+),(-?\d+),(\d+),(-?\d+)', response[1])
    if lte_match:
        rssi = int(lte_match.group(1))
        # rsrp = int(lte_match.group(2))
        # sinr_raw = int(lte_match.group(3))
        # rsrq = int(lte_match.group(4))
        # sinr_db = (sinr_raw / 2.0) - 23.5
        return rssi

    # GSM pattern
    gsm_match = re.search(r'\+QCSQ:\s*"GSM",(-?\d+)', response[1])
    if gsm_match:
        gsm_rssi = int(gsm_match.group(1))
        return gsm_rssi

    # No match
    return -127


def publishMsgs(TOPIC:str, response:str) -> bool:
    pub_start = sendATcommand(f"AT+QMTPUBEX=0,0,0,0,\"{TOPIC}\", {len(response)}", timeout=20, expected_response=">")
    if pub_start == False:
        datalogger.error("unable to publish")
        return False
    time.sleep(1)
    if sendATcommand(response, timeout=20, expected_response="+QMTPUBEX:")[0] != ERR_Codes.NO_ERR:
        datalogger.error("Cannot publish response")
        return False
    datalogger.info("Response published")
    return True


def loadLastSyncedTime(filepath=SYNC_FILE) -> float:
    try:
        with open(filepath, "r") as f:
            line = f.readline().strip()
            return float(line)
    except (FileNotFoundError, ValueError):
        datalogger.error(traceback.format_exc())
        return 0  # File missing or invalid content


def getCurrentTimeInModule() -> datetime:
    """
    Parse AT+CCLK? response and return a UTC datetime object.
    """
    cclk_response = sendATcommand("AT+CCLK?", expected_response="+CCLK:")
    if cclk_response[0] != ERR_Codes.NO_ERR:
        return datetime.fromtimestamp(time.time())
    match = re.search(r'\+CCLK: "(\d+)/(\d+)/(\d+),(\d+):(\d+):(\d+)([+-]\d+)"', cclk_response[1])
    if not match:
        return datetime.fromtimestamp(time.time())

    year, month, day, hour, minute, second, tz_offset = match.groups()
    # Convert 2-digit year to 4-digit year
    year = int(year) + 2000
    month = int(month)
    day = int(day)
    hour = int(hour)
    minute = int(minute)
    second = int(second)

    tz_offset_minutes = (int(tz_offset)) * 15  # each unit = 15 minutes (Quectel standard)
    tz = timezone(timedelta(minutes=tz_offset_minutes))

    dt = datetime(year, month, day, hour, minute, second, tzinfo=tz)

    # Convert to UTC
    dt_utc = dt.astimezone(IST)
    return dt_utc


def run4GModule() -> bool:
    global GLOB_DEV_STATUS
    if CheckDevPowerState() == DEV_State.POWERED_OFF:
        GLOB_DEV_STATUS = DEV_State.POWERED_OFF

    while(GLOB_DEV_STATUS == DEV_State.POWERED_OFF):
        datalogger.info("device powered OFF, switching ON")
        GLOB_DEV_STATUS = ChangePowerState(PWR_State.TURN_ON)

    time.sleep(2)
    if GLOB_DEV_STATUS == DEV_State.POWER_ON:
        datalogger.info("Device powered ON")
        sendATcommand("AT")
        sendATcommand("ATE0")
        sendATcommand("AT+CMEE=2")
        sendATcommand("AT+COPS=?", timeout=180)
        sendATcommand("AT+COPS=0", timeout=180)  
        sendATcommand("AT+COPS?",  timeout=180)
        sendATcommand("AT+CREG?")
        sendATcommand("AT+CGREG?")
        sendATcommand("AT+QIACT=1", timeout=150)
        if not CheckInternetConnected():
            return False
        GLOB_DEV_STATUS = DEV_State.INTERNET_CONNECTED

    if GLOB_DEV_STATUS == DEV_State.INTERNET_CONNECTED:
        if not CheckInternetConnected():
            GLOB_DEV_STATUS = DEV_State.POWER_ON
            return False
        sendATcommand("AT+QMTCFG=\"recv/mode\",0,1,1") #stores received msgs instead of printing them as urc
        sendATcommand(f"AT+QMTOPEN=0, \"{BROKER_ADDRESS}\", 1883", timeout=120, expected_response="+QMTOPEN:") #response:QMTOPEN:0,0 or 0,1
        sendATcommand(f"AT+QMTCONN=0,\"test1234\", \"{MQTT_USERNAME}\", \"{MQTT_PWD}\"", timeout=10, expected_response="+QMTCONN:")
        if not checkMqttConnStatus():
            return False
        sendATcommand(f"AT+QMTSUB=0,1,\"{SUB_TOPIC}\", 1", timeout=20, expected_response="+QMTSUB:")
        GLOB_DEV_STATUS = DEV_State.MQTT_CONNECTED

    if GLOB_DEV_STATUS == DEV_State.MQTT_CONNECTED:
        if not checkMqttConnStatus():
            GLOB_DEV_STATUS = DEV_State.INTERNET_CONNECTED
            return False
        
        if checkBufferedMsgs():
            datalogger.info("Reading stored Messages from Buffer")
            response = sendATcommand("AT+QMTRECV=0", timeout=20)
            if response[0] != ERR_Codes.NO_ERR:
                return False    
            parseReceivedMsgs(response[1])
        
            while ResponseQueue:
                if not publishMsgs(RESPONSE_TOPIC, json.dumps(ResponseQueue.pop())):
                    return False

        last_sync_time = loadLastSyncedTime()
        if time.time() > (last_sync_time + SYNC_INTERVAL):
            try:
                ntp_time = sendATcommand(f"AT+QNTP=1, \"{NTP_SERVER}\"", timeout=700, expected_response="+QNTP:")
                if ntp_time[0] == ERR_Codes.NO_ERR:  #response: +qntp: 0, time(dd/mm format)
                    response = parseQntpResponse(ntp_time[1])
                    if response[0] == ERR_Codes.NO_ERR:
                        datalogger.info(f"current local time: {response[1]['local_time']}")
                        if setSystemTime(response[1]["datetime_obj"]):
                            with open(SYNC_FILE, "w") as f:
                                f.write(str(time.time()))
                        else:
                            datalogger.error("cannot set system time")
                    else:
                        datalogger.error(f"{response[1]}")
                else:
                    datalogger.warning("cannot sync ntp")
            except Exception as exc:
                datalogger.error(traceback.format_exc())
                datalogger.error(f"Exception: {exc}")

        try:
            cursor.execute(f"SELECT id, payload FROM {TABLE_NAME} ORDER BY id LIMIT {NUM_RECORDS}")
            rows = cursor.fetchall()
            pub_fail:bool = False

            if rows:
                published_records = []
                for record_id, record_json in rows:
                    record = json.loads(record_json)
                    datalogger.debug(f"\nRecord with id={record_id}:\n{record}")
                
                    # Modify the record
                    record['_dataset'][0]['rssi'] = GetSignalStrength()
                    datalogger.info(f"payload:\n{record}")
                    
                    # Publish and delete if publish is successful
                    if publishMsgs(PUBLISH_TOPIC, json.dumps(record)):
                        published_records.append(record_id)
                    else:
                        pub_fail = True
                        break

                if published_records:
                    published_rec_str = ','.join(str(i) for i in published_records)
                    cursor.execute(f"DELETE FROM {TABLE_NAME} WHERE id IN ({published_rec_str})")
                    conn.commit()
                    datalogger.info(f"Deleted records with ids={published_records}")
                
                if pub_fail:
                    return False

        except Exception as exc:
            datalogger.error(f"ERROR Occurred: {exc}")
            datalogger.error(traceback.format_exc())
            return False
    
    return True     



if __name__ == "__main__":
    datalogger = logging.getLogger("Publish Log")
    log_level_str = os.getenv("ADAS_LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_str, logging.INFO)
    datalogger.setLevel(log_level)
    LOG_FILE_HANDLER = RotatingFileHandler(
        # getcwd() + "/build/logs/publish.log",
        "/var/log/adas/adas_log/publish.log",
        maxBytes=MAX_LOG_SIZE,
        backupCount=BACKUP_COUNT,
    )
    LOG_FILE_HANDLER.setFormatter(LOG_FORMAT)
    datalogger.addHandler(LOG_FILE_HANDLER)
    try:
        with open(SYNC_FILE, "w") as f:
            f.write("0")
    except Exception as exc:
        datalogger.error(f"{SYNC_FILE} corrupted {exc}")
        datalogger.error(traceback.format_exc())
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        with serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1) as ser:
            # Give module some time to initialize
            time.sleep(2)
            datalogger.info("Waiting for device to switch ON")
            while ChangePowerState(PWR_State.TURN_ON) == DEV_State.POWERED_OFF:
                time.sleep(1)
            datalogger.debug("Getting time in Module.")
            curr_time = getCurrentTimeInModule()
            datalogger.info(f"IST Time in 4G module {curr_time}")
            if not setSystemTime(curr_time):
                raise SystemError
            datalogger.info("System time updated!")
            datalogger.info(f"Time now: {time.time()}")
            ChangePowerState(PWR_State.REBOOT)
            retry_count = 0
            while(True):
                if retry_count > 4:
                    ChangePowerState(PWR_State.SHUTDOWN)
                    time.sleep(2)
                if run4GModule():
                    retry_count = 0
                else:
                    retry_count +=1