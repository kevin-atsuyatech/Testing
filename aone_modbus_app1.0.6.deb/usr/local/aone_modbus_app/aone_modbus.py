#!/usr/bin/env python3
"""
Pymodbus asynchronous client.
"""
#pymodbus version 3.9.1

import asyncio
import time
import json
import os
import logging
from logging.handlers import RotatingFileHandler
from getmac import get_mac_address
import sqlite3
import traceback

import pymodbus.client as ModbusClient
from pymodbus import (
    FramerType,
    ModbusException,
    pymodbus_apply_logging_config,
)

DEVICE_RUN_CONFIG:dict = {
                "IP_ADDRESS"      : "192.168.1.24",
                "PORT"            : 502,
                "READ_INTERVAL"   : 10
                }
CONFIG_FILE     = "/var/log/adas/config/config_file.json"
VARIABLE_FILE   = "/var/log/adas/config/variables.json"

MAC             = get_mac_address(interface="wlan0").upper()
DB_PATH         = "/var/log/adas/config/modbus.db"
TABLE_NAME      = "modbus_data"

MAX_LOG_SIZE    = 10 * 1024 * 1024                              # 1 MB (adjust as needed)
BACKUP_COUNT    = 5                                             # Number of backup log files to keep
LOG_FORMAT      = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")


class ModbusConfigError(Exception):
    def __init__(self, code, reg_type, start_addr, addr_len, message="Modbus Configuration Error"):
        regs = ["COILS", "DISCRETE", "HOLDING", "INPUT"]
        self.code = code
        super().__init__(f"[{code}]\r\nREG:{regs[reg_type-1]}\r\nAddress:{start_addr}\r\nLen:{addr_len}\r\nError:{message}")


def generate_payload(data_dict:dict, mod_state = 0) -> json:
    """Generate the JSON payload."""
    payload_json:json = {
        "_dataset": [
            {
                "deviceId": MAC,
                "type": "GENERIC",
                "modState": mod_state,
                "rssi": None,
                "msv": 4.941391945,
                "bsv": 4.199999809,
                "bsp": 100,
                "data": [
                    {
                        "time": int(time.time() * 1000),
                        **data_dict
                    }
                ]
            }
        ]
    }
    
    # datalogger.info(f"payload :\n {json.dumps(payload_json, indent=2)}")
    datalogger.info(f"payload :\n {json.dumps(payload_json, separators=(',', ':'))}")
    return payload_json


async def save_to_db(payload) -> None:
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        try:
            # Create table if not exists (adjust schema as needed)
            cursor.execute(f"""
                CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    payload TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Insert payload as JSON string
            cursor.execute(f"INSERT INTO {TABLE_NAME} (payload) VALUES (?)", (json.dumps(payload),))

            # Commit and close connection
            conn.commit()

            datalogger.info("Data saved to DB")
        except Exception as exc:
            datalogger.error(f"Exception occurred while saving: {exc}")
            datalogger.error(traceback.format_exc())


async def read_modbus_data(host, port, timeout=10, retries=3, framer=FramerType.SOCKET) -> None:
    """Run async client."""
    mod_state = 0
    coil_data =  {label["n"]: None for item in coil_list for label in item["reg"]}
    discrete_data =  {label["n"]: None for item in discrete_list for label in item["reg"]}
    holding_data =  {label["n"]: None for item in holding_list for label in item["reg"]}
    input_data =  {label["n"]: None for item in input_list for label in item["reg"]}
    client: ModbusClient.ModbusBaseClient
    try:
        client = ModbusClient.AsyncModbusTcpClient(
        host,
        port=port,
        framer=framer,
        timeout=timeout,
        retries=retries,
    )
        datalogger.info("trying to connect to Modbus server")
        await client.connect()
        try:
            assert client.connected
        except AssertionError:
            datalogger.error(f"Cannot connect to client")
            return

        datalogger.info("Connected, Starting read")
        try:
            for list_item in coil_list:
                rr = await client.read_coils(address=list_item["adr"], count=list_item["len"], slave=list_item["slave"])
                if not rr.isError():
                    bits = rr.bits
                    datalogger.debug(f"Got coils: {bits}")
                    for j in range(0, len(list_item["reg"])):
                        coil_data[list_item["reg"][j]["n"]] = int(bits[j])  #if i < len(bits) else None
                else:
                    mod_state = rr.exception_code
                    datalogger.error(f"Received exception from device ({rr}) while reading coils")
        except ModbusException as exc:
            datalogger.error(f"Received ModbusException({exc}) from library while reading coils")
            datalogger.error(traceback.format_exc())
        
        try:
            for list_item in discrete_list:
                rr = await client.read_discrete_inputs(address=list_item["adr"], count=list_item["len"], slave=list_item["slave"])
                if not rr.isError():
                    bits = rr.bits
                    datalogger.debug(f"Got discrete inputs: {bits}")
                    for j in range(0, len(list_item["reg"])):
                        discrete_data[list_item["reg"][j]["n"]] = int(bits[j])  #if i < len(bits) else None
                else:
                    mod_state = rr.exception_code
                    datalogger.error(f"Received exception from device ({rr}) while reading discrete inputs")
        except ModbusException as exc:
            datalogger.error(f"Received ModbusException({exc}) from library while reading discrete inputs")
            datalogger.error(traceback.format_exc())
    
        try:
            for list_item in holding_list:
                rr = await client.read_holding_registers(address=list_item["adr"], count=list_item["len"], slave=list_item["slave"])
                if not rr.isError():
                    start_offset = 0
                    end_offset = 0
                    for i in list_item["reg"]:
                        i:dict
                        match i["t"]:
                            case "u16":
                                end_offset += 1
                                datatype = client.DATATYPE.UINT16
                            case "u32":
                                end_offset += 2
                                datatype = client.DATATYPE.UINT32
                            case "u64":
                                end_offset += 4
                                datatype = client.DATATYPE.UINT64
                            case "i16":
                                end_offset += 1
                                datatype = client.DATATYPE.INT16
                            case "i32":
                                end_offset += 2
                                datatype = client.DATATYPE.INT32
                            case "i64":
                                end_offset += 4
                                datatype = client.DATATYPE.INT64
                            case "f32":
                                end_offset += 2
                                datatype = client.DATATYPE.FLOAT32
                            case "f64":
                                end_offset += 4
                                datatype = client.DATATYPE.FLOAT64
                            case _:
                                raise ModbusException
                        value = client.convert_from_registers(rr.registers[start_offset:end_offset], data_type=datatype, word_order=i.get("wo", "little"))
                        datalogger.debug(f"Got value: {value}")
                        start_offset = end_offset
                        holding_data[i["n"]] = value
                else:
                    mod_state = rr.exception_code
                    datalogger.error(f"Received exception from device ({rr}) while reading holding regs")
        except ModbusException as exc:
            datalogger.error(f"Received ModbusException({exc}) from library while reading holding regs")
            datalogger.error(traceback.format_exc())
        
        try:
            for list_item in input_list:
                rr = await client.read_input_registers(address=list_item["adr"], count=list_item["len"], slave=list_item["slave"])
                if not rr.isError():
                    start_offset = 0
                    end_offset = 0
                    for i in list_item["reg"]:
                        i:dict
                        match i["t"]:
                            case "u16":
                                end_offset += 1
                                datatype = client.DATATYPE.UINT16
                            case "u32":
                                end_offset += 2
                                datatype = client.DATATYPE.UINT32
                            case "u64":
                                end_offset += 4
                                datatype = client.DATATYPE.UINT64
                            case "i16":
                                end_offset += 1
                                datatype = client.DATATYPE.INT16
                            case "i32":
                                end_offset += 2
                                datatype = client.DATATYPE.INT32
                            case "i64":
                                end_offset += 4
                                datatype = client.DATATYPE.INT64
                            case "f32":
                                end_offset += 2
                                datatype = client.DATATYPE.FLOAT32
                            case "f64":
                                end_offset += 4
                                datatype = client.DATATYPE.FLOAT64
                            case _:
                                raise ModbusException
                        value = client.convert_from_registers(rr.registers[start_offset:end_offset], data_type=datatype, word_order=i.get("wo", "little"))
                        datalogger.debug(f"Got value: {value}")
                        start_offset = end_offset
                        input_data[i["n"]] = value
                else:
                    mod_state = rr.exception_code
                    datalogger.error(f"Received exception from device ({rr}) while reading input regs")
        except ModbusException as exc:
            datalogger.error(f"Received ModbusException({exc}) from library while reading input regs")
            datalogger.error(traceback.format_exc())
    except Exception as exc:
        datalogger.error(f"Got exception {exc}")
        datalogger.error(traceback.format_exc())
    finally:
        combined_dict = {**coil_data, **discrete_data, **holding_data, **input_data}
        await save_to_db(generate_payload(combined_dict, mod_state=mod_state))
        datalogger.info("close connection")
        client.close()


async def periodic_modbus_reader() -> None:
    while True:
        try:
            with open(VARIABLE_FILE, "r") as f:
                env_vars = json.load(f)
                DEVICE_RUN_CONFIG = env_vars
        except Exception as exc:
            datalogger.error(f"Cannot read vars: {exc}")
            datalogger.error(traceback.format_exc())
            datalogger.warning(f"Loading default vars: IP:{DEVICE_RUN_CONFIG['IP_ADDRESS']},"
                           f"PORT:{DEVICE_RUN_CONFIG['PORT']}, INTERVAL:{DEVICE_RUN_CONFIG['READ_INTERVAL']}")
        start_time = time.time()

        await read_modbus_data(host= DEVICE_RUN_CONFIG["IP_ADDRESS"], port= DEVICE_RUN_CONFIG["PORT"])

        elapsed = time.time() - start_time
        sleep_time = max(0, DEVICE_RUN_CONFIG["READ_INTERVAL"] - elapsed)
        await asyncio.sleep(sleep_time)


def parseConfigJSON(modbusConfig:dict) -> bool:
    try:
        for block in modbusConfig["mod_config"]:
            fc  = block["fc"]
            adrlen = block["len"]
            adr = block["adr"]
            slave = block["slave"]
            if slave < 0 or slave > 255:
                datalogger.error(f"Invalid slave id: {slave}")
                return False
            if fc in [1, 2]:
                reglen  = len(list(block["reg"]))
                if adrlen != reglen:
                    raise ModbusConfigError(ValueError, fc, adr, adrlen, f"Length of reg should match number of registers")
            elif fc in [3, 4]:
                sum = 0
                for reg in block["reg"]:
                    if "16" in reg["t"]:
                        sum += 1 
                    elif "32" in reg["t"]:
                        sum += 2
                    elif "64" in reg["t"]:
                        sum +=4
                    else:
                        raise ModbusConfigError(TypeError, fc, adr, adrlen, "invalid type")
                if sum != adrlen:
                    raise ModbusConfigError(ValueError, fc, adr, adrlen, f"Length of reg should match number of registers")
        return True
    except Exception as exc:
        datalogger.error(f"{exc}")
        datalogger.error(traceback.format_exc())
        return False


def createDataLists(modbusConfig: dict) -> None:
    for block in modbusConfig["mod_config"]:
        fc = block["fc"]
        if fc == 1:
            coil_list.append(block)
        elif fc == 2:
            discrete_list.append(block)
        elif fc == 3:
            holding_list.append(block)
        elif fc == 4:
            input_list.append(block)


if __name__ == "__main__":
    datalogger = logging.getLogger("ModBus Log")
    log_level_str = os.getenv("ADAS_LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_str, logging.INFO)
    datalogger.setLevel(log_level)
    LOG_FILE_HANDLER = RotatingFileHandler(
        # getcwd() + "/build/logs/modbus.log",
        "/var/log/adas/adas_log/modbus.log",
        maxBytes=MAX_LOG_SIZE,
        backupCount=BACKUP_COUNT,
    )
    LOG_FILE_HANDLER.setFormatter(LOG_FORMAT)
    datalogger.addHandler(LOG_FILE_HANDLER)
    coil_list       = []
    discrete_list   = []
    holding_list    = []
    input_list      = []
    try:
        with open(CONFIG_FILE, "r") as f:
            device_config = json.load(f)
            if not parseConfigJSON(device_config):
                datalogger.error("cannot parse config")
                exit()
            datalogger.error("config parsed successfully")
            createDataLists(device_config)
    except (FileNotFoundError, ValueError) as exc:
        datalogger.error(f"{CONFIG_FILE} corrupted: {exc}")
        datalogger.error(traceback.format_exc())
        exit()
    # enable debugging
    # pymodbus_apply_logging_config("DEBUG")
    datalogger.info(f"Device MAC: {MAC}")
    asyncio.run(
        # read_modbus_data(host= IP_ADDRESS, port= PORT)
        periodic_modbus_reader()
    )