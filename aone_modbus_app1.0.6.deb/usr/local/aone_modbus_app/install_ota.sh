#!/bin/bash

PACKAGE_PATH="$1"
LOG_FILE="/var/log/adas/adas_log/ota_install.log"

if [ -z "$PACKAGE_PATH" ]; then
  echo "Usage: $0 /path/to/package.deb"
  exit 1
fi

echo "Starting OTA install at $(date)" >> "$LOG_FILE"

# Optional: delay to allow calling script to finish
sleep 10

# Stop service before upgrade
systemctl stop adas_modbus.service

# Run the installation and log output
# sudo dpkg -i "$PACKAGE_PATH" > "$LOG_FILE" 2>&1
apt install -y "$PACKAGE_PATH" >> "$LOG_FILE" 2>&1