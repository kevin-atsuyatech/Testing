import subprocess
import signal
import sys
import time

# Paths to your scripts
MODBUS_SCRIPT = "aone_modbus.py"
PUBLISHER_SCRIPT = "aone_4g_mqtt.py"

# Store subprocess references
processes = []

def start_process(script):
    return subprocess.Popen([sys.executable, script])

def shutdown_service(signum, frame):
    print("Shutting down service...")
    for p in processes:
        p.terminate()
    for p in processes:
        p.wait()
    sys.exit(0)

if __name__ == "__main__":
    # Handle Ctrl+C or kill signals
    signal.signal(signal.SIGINT, shutdown_service)
    signal.signal(signal.SIGTERM, shutdown_service)

    try:
        print("Starting Modbus Reader...")
        modbus_proc = start_process(MODBUS_SCRIPT)

        print("Starting JSON Publisher...")
        publisher_proc = start_process(PUBLISHER_SCRIPT)

        processes = [modbus_proc, publisher_proc]

        # Keep the main process alive to manage subprocesses
        while True:
            time.sleep(1)

    except Exception as e:
        print(f"Service crashed: {e}")
        shutdown_service(None, None)
